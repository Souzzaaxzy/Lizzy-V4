# BypassKN Defensive Guard (v2.0.0)

Camada defensiva para análise de mensagens recebidas e observabilidade em bots Node.js que usam a API de eventos comum do Baileys. Inclui limites de varredura pós-decodificação, indicadores estruturais, rate limit por chat/remetente, auditoria redigida e adaptador de eventos.

## Instalação e testes

Requer Node.js 18 ou superior. Extraia a pasta e execute:

```bash
npm test
npm run check
```

## Integração mínima

```js
const { attachBaileysGuard } = require('./bypasskn/src');

const guardHandle = attachBaileysGuard(sock, {
  maxDepth: 10,
  maxNodes: 2500,
  maxProperties: 12000,
  maxArrayItems: 600,
  rateLimit: { capacity: 45, refillPerSecond: 1.5, maxTrackedKeys: 10000 },
  onResult: async ({ message, result }) => {
    if (result.recommendedAction === 'quarantine_for_review') {
      // Registre/coloque em fila de revisão; não bane com base apenas em heurística.
      console.warn('[BypassKN]', result.classification, result.findings.map(x => x.code));
      return;
    }
    if (result.recommendedAction === 'rate_limited') {
      // Aplique sua política de ingestão/handler com cuidado; o evento já chegou decodificado.
      return;
    }
    // Encaminhe mensagens normais ao handler da aplicação.
  }
});

// Ao desligar o bot: guardHandle.detach();
```

**Importante:** este adaptador é pós-decodificação e observa `messages.upsert`. Ele não intercepta nem limita o parser protobuf, o transporte, a descriptografia ou o custo de memória antes de o Baileys emitir o evento. Para proteção pré-decodificação, a implementação precisa ser inserida no caminho exato de recepção/decodificação da versão/commit usado pelo seu fork. Não copie patches de criptografia ou de Sender Key sem validar o protocolo e testes de interoperabilidade.

## O que inclui

- Varredura com limites de profundidade, nós, propriedades, itens de arrays, tamanho de strings e quantidade de achados.
- Detecção heurística de textos/captions longos, raízes com múltiplos tipos, wrappers cíclicos e estruturas incompletas.
- Rate limiter token-bucket limitado em memória por chat/remetente.
- Auditoria em buffer limitado, sem texto da mensagem e com IDs parcialmente redigidos.
- Classificação conservadora e recomendação de revisão; banimento automático permanentemente desativado.
- Testes automatizados para limites, ciclos, rate limit e integração do listener.

## Limites e segurança

Não existe proteção que detecte com certeza todas as tentativas de abuso ou todas as violações de políticas. Tipos novos/legítimos podem ser desconhecidos, e heurísticas produzem falsos positivos. A análise deste pacote ocorre depois da decodificação e, portanto, não impede sozinha ataques que esgotem recursos durante parsing, protobuf, decrypt ou download de mídia. Não manipula chaves, ciphertext, sessões, Sender Keys nem tenta tornar mensagens invisíveis.

Para implantação real, confirme o schema/protobuf exato e o commit do fork, acrescente limites no caminho pré-decode, imponha limites de download de mídia/tempo/concorrência, mantenha dependências atualizadas, teste em ambiente isolado e monitore falsos positivos. Não use a classificação isoladamente para banimentos.
