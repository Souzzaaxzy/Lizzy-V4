'use strict';
const { DefensiveGuard } = require('./guard');

/**
 * Adaptador pós-decodificação para a API de eventos usual do Baileys.
 * Não altera chaves, ciphertext, Sender Keys, sessões ou mensagens recebidas.
 * O callback decide como encaminhar/quarentenar; o adaptador não bane nem apaga mensagens.
 */
function attachBaileysGuard(sock, options = {}) {
  if (!sock?.ev || typeof sock.ev.on !== 'function') throw new TypeError('Socket Baileys inválido: esperado sock.ev.on');
  const guard = options.guard || new DefensiveGuard(options);
  const onUpsert = async ({ messages = [], type } = {}) => {
    for (const message of messages) {
      let result;
      try { result = guard.inspect(message); }
      catch (error) {
        result = { classification: 'INCONCLUSIVE', recommendedAction: 'observe', shouldProcess: true, shouldAutoBan: false, findings: [{ code: 'GUARD_INTERNAL_ERROR' }], errorName: error?.name || 'Error' };
      }
      try {
        if (typeof options.onResult === 'function') await options.onResult({ message, result, upsertType: type });
      } catch { /* falha do callback não deve causar rejeição não tratada no listener */ }
    }
  };
  sock.ev.on('messages.upsert', onUpsert);
  return {
    guard,
    detach() {
      if (typeof sock.ev.off === 'function') sock.ev.off('messages.upsert', onUpsert);
      else if (typeof sock.ev.removeListener === 'function') sock.ev.removeListener('messages.upsert', onUpsert);
    }
  };
}
module.exports = { attachBaileysGuard };
