'use strict';

class AuditBuffer {
  constructor({ enabled = true, maxEvents = 2000, sink = null } = {}) { this.enabled = enabled; this.maxEvents = maxEvents; this.sink = sink; this.events = []; }
  record(event) {
    if (!this.enabled) return;
    const safe = {
      at: new Date().toISOString(), type: String(event.type || 'security_event').slice(0, 80),
      chatId: redactId(event.chatId), senderId: redactId(event.senderId),
      classification: String(event.classification || 'unknown').slice(0, 60),
      codes: Array.isArray(event.codes) ? event.codes.slice(0, 30).map(x => String(x).slice(0, 80)) : [],
      action: String(event.action || 'observe').slice(0, 40)
    };
    this.events.push(safe);
    if (this.events.length > this.maxEvents) this.events.splice(0, this.events.length - this.maxEvents);
    if (typeof this.sink === 'function') { try { this.sink(safe); } catch { /* auditoria não pode derrubar a recepção */ } }
  }
  snapshot() { return this.events.map(e => ({ ...e, codes: [...e.codes] })); }
}
function redactId(v) {
  if (v == null) return null;
  const s = String(v);
  if (s.length <= 8) return '[redacted]';
  return `${s.slice(0, 3)}…${s.slice(-4)}`;
}
module.exports = { AuditBuffer, redactId };
