'use strict';

const { measureContent, WRAPPER_KEYS, TEXT_FIELDS_BY_TYPE } = require('./contentAnomalies');

const KNOWN_TYPES = new Set(Object.keys(TEXT_FIELDS_BY_TYPE).concat([
  'protocolMessage','senderKeyDistributionMessage','messageContextInfo','reactionMessage','stickerPackMessage',
  'groupInviteMessage','groupMentionMessage','pinInChatMessage','keepInChatMessage','pollUpdateMessage',
  'listResponseMessage','buttonsResponseMessage','templateButtonReplyMessage','interactiveResponseMessage',
  'requestPaymentMessage','paymentRequestMessage','paymentInviteMessage','encryptedReactionMessage'
]));
const WRAPPERS = new Set(WRAPPER_KEYS);

function inspectMessageRoot(message) {
  const root = message?.message;
  if (!root || typeof root !== 'object' || Array.isArray(root)) return { validRoot: false, types: [], wrapperDepth: 0, leafType: null, flags: ['MISSING_OR_INVALID_MESSAGE_ROOT'] };
  const flags = [], types = Object.keys(root), seen = new Set();
  if (types.length === 0) flags.push('EMPTY_MESSAGE_ROOT');
  if (types.length > 1) flags.push('MULTIPLE_MESSAGE_TYPES_AT_ROOT');
  let current = root, wrapperDepth = 0, leafType = null;
  while (current && typeof current === 'object' && !Array.isArray(current)) {
    const keys = Object.keys(current);
    const wrapper = keys.find(k => WRAPPERS.has(k) && current[k] && typeof current[k] === 'object' && current[k].message && typeof current[k].message === 'object');
    if (!wrapper) { leafType = keys.find(k => KNOWN_TYPES.has(k)) || keys[0] || null; break; }
    if (seen.has(current)) { flags.push('WRAPPER_CYCLE'); break; }
    seen.add(current); wrapperDepth++; current = current[wrapper].message;
    if (wrapperDepth > 10) { flags.push('WRAPPER_DEPTH_EXCEEDED'); break; }
  }
  if (leafType && !KNOWN_TYPES.has(leafType)) flags.push('UNKNOWN_LEAF_TYPE');
  return { validRoot: true, types, wrapperDepth, leafType, flags };
}

function analyzeMessage(message, options = {}) {
  const structural = inspectMessageRoot(message);
  const content = measureContent(message?.message ?? message, options);
  const findings = [];
  for (const f of structural.flags) findings.push({ code: f, severity: f === 'UNKNOWN_LEAF_TYPE' ? 'low' : 'medium' });
  for (const f of content.findings) findings.push({ ...f, severity: f.code === 'TEXT_LENGTH_SEVERE' || f.code.includes('RESOURCE_LIMIT') || f.code === 'ARRAY_TOO_LARGE' ? 'high' : 'medium' });
  if (content.truncated) findings.push({ code: 'ANALYSIS_INCOMPLETE', severity: 'medium', reasons: content.truncationReasons });
  const high = findings.some(f => f.severity === 'high');
  const medium = findings.some(f => f.severity === 'medium');
  const classification = high ? 'HIGH_SEVERITY_REVIEW' : medium ? 'SUSPICIOUS_REVIEW' : 'NORMAL_OR_UNCONFIRMED';
  return {
    classification,
    validRoot: structural.validRoot,
    messageTypes: structural.types,
    leafType: structural.leafType,
    wrapperDepth: structural.wrapperDepth,
    findings: findings.slice(0, options.maxFindings ?? 80),
    contentCounters: content.counters,
    analysisTruncated: content.truncated,
    automaticPunishment: false,
    confidenceNote: 'Heurísticas pós-decodificação; não provam intenção maliciosa nem substituem validação do protocolo.'
  };
}

module.exports = { analyzeMessage, inspectMessageRoot, KNOWN_TYPES, WRAPPERS };
