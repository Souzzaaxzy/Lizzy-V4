'use strict';

class TokenBucketLimiter {
  constructor({ capacity = 45, refillPerSecond = 1.5, maxTrackedKeys = 10000, now = () => Date.now() } = {}) {
    if (!(capacity >= 1) || !(refillPerSecond > 0) || !(maxTrackedKeys >= 1)) throw new TypeError('Parâmetros inválidos do rate limiter');
    this.capacity = capacity; this.refillPerSecond = refillPerSecond; this.maxTrackedKeys = maxTrackedKeys; this.now = now; this.buckets = new Map();
  }
  consume(key, cost = 1) {
    const id = String(key || 'unknown').slice(0, 300), now = this.now();
    let b = this.buckets.get(id) || { tokens: this.capacity, updatedAt: now };
    b.tokens = Math.min(this.capacity, b.tokens + Math.max(0, now - b.updatedAt) / 1000 * this.refillPerSecond);
    b.updatedAt = now;
    const allowed = cost <= b.tokens;
    if (allowed) b.tokens -= cost;
    this.buckets.delete(id); this.buckets.set(id, b);
    while (this.buckets.size > this.maxTrackedKeys) this.buckets.delete(this.buckets.keys().next().value);
    return { allowed, remaining: Math.max(0, Math.floor(b.tokens)), retryAfterMs: allowed ? 0 : Math.ceil((cost - b.tokens) / this.refillPerSecond * 1000) };
  }
  get size() { return this.buckets.size; }
  clear() { this.buckets.clear(); }
}
module.exports = { TokenBucketLimiter };
