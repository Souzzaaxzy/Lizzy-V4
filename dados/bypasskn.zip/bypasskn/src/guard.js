'use strict';
const { mergeConfig } = require('./config');
const { analyzeMessage } = require('./invisibleAnalyzer');
const { TokenBucketLimiter } = require('./rateLimiter');
const { AuditBuffer } = require('./audit');

class DefensiveGuard {
  constructor(options = {}) {
    this.config = mergeConfig(options);
    this.limiter = options.limiter || new TokenBucketLimiter(this.config.rateLimit);
    this.audit = options.auditBuffer || new AuditBuffer({ ...this.config.audit, sink: options.auditSink });
  }
  inspect(message) {
    const key = message?.key || {};
    const chatId = key.remoteJid || 'unknown-chat';
    const senderId = key.participant || key.remoteJid || 'unknown-sender';
    const rate = this.limiter.consume(`${chatId}|${senderId}`);
    const analysis = analyzeMessage(message, this.config);
    let action = 'observe';
    if (!rate.allowed && this.config.actions.dropOnRateLimit) action = 'rate_limited';
    else if (analysis.classification === 'HIGH_SEVERITY_REVIEW' && this.config.actions.quarantineOnHighSeverity) action = 'quarantine_for_review';
    // Banimento automático deliberadamente desativado: heurísticas podem gerar falsos positivos.
    const result = { ...analysis, rateLimit: rate, recommendedAction: action, shouldProcess: action === 'observe', shouldAutoBan: false };
    this.audit.record({ type: 'message_inspected', chatId, senderId, classification: result.classification, codes: result.findings.map(f => f.code), action });
    return result;
  }
}
module.exports = { DefensiveGuard };
