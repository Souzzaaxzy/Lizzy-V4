'use strict';

const DEFAULTS = Object.freeze({
  maxDepth: 10,
  maxNodes: 2500,
  maxProperties: 12000,
  maxArrayItems: 600,
  maxStringChars: 100000,
  suspiciousTextChars: 2000,
  severeTextChars: 100000,
  maxFindings: 80,
  rateLimit: { capacity: 45, refillPerSecond: 1.5, maxTrackedKeys: 10000 },
  actions: { quarantineOnHighSeverity: true, dropOnRateLimit: true, autoBan: false },
  audit: { enabled: true, maxEvents: 2000, includeMessageText: false }
});

function mergeConfig(input = {}) {
  const c = {
    ...DEFAULTS,
    ...input,
    rateLimit: { ...DEFAULTS.rateLimit, ...(input.rateLimit || {}) },
    actions: { ...DEFAULTS.actions, ...(input.actions || {}) },
    audit: { ...DEFAULTS.audit, ...(input.audit || {}) }
  };
  for (const k of ['maxDepth','maxNodes','maxProperties','maxArrayItems','maxStringChars','suspiciousTextChars','severeTextChars','maxFindings']) {
    if (!Number.isSafeInteger(c[k]) || c[k] < 1) throw new TypeError(`Configuração inválida: ${k}`);
  }
  if (!(c.rateLimit.capacity >= 1) || !(c.rateLimit.refillPerSecond > 0) || !(c.rateLimit.maxTrackedKeys >= 1)) throw new TypeError('Configuração rateLimit inválida');
  return c;
}

module.exports = { DEFAULTS, mergeConfig };
