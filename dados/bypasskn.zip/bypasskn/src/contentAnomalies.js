'use strict';

const TEXT_FIELDS_BY_TYPE = Object.freeze({
  conversation: [''], extendedTextMessage: ['text'], imageMessage: ['caption'], videoMessage: ['caption'],
  documentMessage: ['caption', 'fileName'], audioMessage: [], stickerMessage: [],
  locationMessage: ['name', 'address'], liveLocationMessage: ['caption'], contactMessage: ['displayName'],
  contactsArrayMessage: [], listMessage: ['title', 'description', 'buttonText', 'footerText'],
  buttonsMessage: ['contentText', 'footerText'], templateMessage: ['hydratedTemplate', 'fourRowTemplate'],
  pollCreationMessage: ['name'], pollCreationMessageV2: ['name'], pollCreationMessageV3: ['name'],
  eventMessage: ['name', 'description', 'location'], productMessage: ['title', 'description'],
  requestPhoneNumberMessage: [], paymentInviteMessage: ['serviceType'],
  declinePaymentRequestMessage: ['key'], cancelPaymentRequestMessage: ['key']
});

const WRAPPER_KEYS = new Set(['ephemeralMessage','viewOnceMessage','viewOnceMessageV2','viewOnceMessageV2Extension','documentWithCaptionMessage','editedMessage','deviceSentMessage']);
const CONTAINER_KEYS = new Set(['message','msg','content','contextInfo','quotedMessage','interactiveMessage','nativeFlowMessage','header','body','footer','hydratedTemplate','fourRowTemplate','templateButtonReplyMessage']);
const STRUCTURAL_STRING_KEYS = new Set(['id','key','jid','remoteJid','participant','fileName','mimetype','mediaKey','fileSha256','fileEncSha256','messageSecret','token','url','directPath','thumbnailDirectPath','serviceType','currency','amount','timestamp','stanzaId']);

function isPlainContainer(v) { return v !== null && typeof v === 'object' && !Buffer.isBuffer(v) && !(v instanceof Date); }

function measureContent(root, options = {}) {
  const limits = {
    maxDepth: options.maxDepth ?? 10, maxNodes: options.maxNodes ?? 2500,
    maxProperties: options.maxProperties ?? 12000, maxArrayItems: options.maxArrayItems ?? 600,
    maxStringChars: options.maxStringChars ?? 100000, suspiciousTextChars: options.suspiciousTextChars ?? 2000,
    severeTextChars: options.severeTextChars ?? 100000, maxFindings: options.maxFindings ?? 80
  };
  const findings = [], reasons = [], seen = new WeakSet();
  let nodes = 0, properties = 0, arrays = 0, strings = 0, truncated = false;
  const add = f => { if (findings.length < limits.maxFindings) findings.push(f); else truncated = true; };
  const stop = why => { truncated = true; if (!reasons.includes(why)) reasons.push(why); };

  function visit(value, path, depth, parentType, keyName) {
    if (++nodes > limits.maxNodes) { stop('maxNodes'); return; }
    if (depth > limits.maxDepth) { stop('maxDepth'); return; }
    if (typeof value === 'string') {
      strings++;
      const field = keyName || '';
      const structural = STRUCTURAL_STRING_KEYS.has(field);
      const textLike = !structural && (field === '' || ['text','caption','name','description','title','address','contentText','footerText','buttonText','displayName','conversation'].includes(field) || TEXT_FIELDS_BY_TYPE[parentType]?.includes(field));
      if (textLike && value.length > limits.suspiciousTextChars) add({ code: value.length >= limits.severeTextChars ? 'TEXT_LENGTH_SEVERE' : 'TEXT_LENGTH_HIGH', path, length: value.length, limit: value.length >= limits.severeTextChars ? limits.severeTextChars : limits.suspiciousTextChars });
      if (value.length > limits.maxStringChars) { add({ code: 'STRING_RESOURCE_LIMIT', path, length: value.length, limit: limits.maxStringChars }); stop('maxStringChars'); }
      return;
    }
    if (!isPlainContainer(value)) return;
    if (seen.has(value)) { add({ code: 'CIRCULAR_REFERENCE', path }); return; }
    seen.add(value);
    if (Array.isArray(value)) {
      arrays++;
      if (value.length > limits.maxArrayItems) { add({ code: 'ARRAY_TOO_LARGE', path, length: value.length, limit: limits.maxArrayItems }); stop('maxArrayItems'); }
      const n = Math.min(value.length, limits.maxArrayItems);
      for (let i = 0; i < n && nodes <= limits.maxNodes; i++) visit(value[i], `${path}[${i}]`, depth + 1, parentType, String(i));
      return;
    }
    let entries;
    try { entries = Object.entries(value); } catch { add({ code: 'OBJECT_ENUMERATION_FAILED', path }); return; }
    properties += entries.length;
    if (properties > limits.maxProperties) { add({ code: 'PROPERTY_RESOURCE_LIMIT', path, count: properties, limit: limits.maxProperties }); stop('maxProperties'); entries = entries.slice(0, Math.max(0, limits.maxProperties - (properties - entries.length))); }
    const ownTypeKeys = entries.filter(([k]) => Object.hasOwn(TEXT_FIELDS_BY_TYPE, k));
    if (depth === 0 && ownTypeKeys.length > 1) add({ code: 'MULTIPLE_ROOT_MESSAGE_TYPES', path, types: ownTypeKeys.map(([k]) => k).slice(0, 10) });
    for (const [k, child] of entries) {
      if (nodes > limits.maxNodes || truncated && reasons.includes('maxProperties')) break;
      const nextType = Object.hasOwn(TEXT_FIELDS_BY_TYPE, k) ? k : parentType;
      visit(child, path ? `${path}.${k}` : k, depth + 1, nextType, k);
    }
  }
  visit(root, '', 0, null, '');
  return { findings, truncated, truncationReasons: reasons, counters: { nodes, properties, arrays, strings }, limits };
}

module.exports = { measureContent, TEXT_FIELDS_BY_TYPE, WRAPPER_KEYS, STRUCTURAL_STRING_KEYS };
