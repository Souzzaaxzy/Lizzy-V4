'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const { measureContent, analyzeMessage, TokenBucketLimiter, DefensiveGuard, attachBaileysGuard } = require('../src');

test('detecta legenda grande sem guardar o texto no resultado', () => {
  const r = measureContent({ imageMessage: { caption: 'x'.repeat(2501) } });
  assert.ok(r.findings.some(f => f.code === 'TEXT_LENGTH_HIGH'));
  assert.equal(JSON.stringify(r).includes('xxxx'), false);
});
test('marca texto extremamente longo como alta gravidade', () => {
  const r = analyzeMessage({ key: {}, message: { conversation: 'x'.repeat(100001) } });
  assert.equal(r.classification, 'HIGH_SEVERITY_REVIEW');
  assert.equal(r.automaticPunishment, false);
});
test('marca múltiplos tipos na raiz', () => {
  const r = analyzeMessage({ message: { conversation: 'oi', imageMessage: {} } });
  assert.ok(r.findings.some(f => f.code === 'MULTIPLE_MESSAGE_TYPES_AT_ROOT'));
});
test('limita a profundidade e informa análise incompleta', () => {
  let x = {}; let root = x; for (let i=0;i<20;i++) root = root.a = {};
  const r = measureContent(x, { maxDepth: 4 });
  assert.equal(r.truncated, true);
  assert.ok(r.truncationReasons.includes('maxDepth'));
});
test('não quebra com referências circulares', () => {
  const x = {}; x.self = x;
  assert.ok(measureContent(x).findings.some(f => f.code === 'CIRCULAR_REFERENCE'));
});
test('rate limiter limita rajada e mantém mapa limitado', () => {
  let now = 0; const l = new TokenBucketLimiter({ capacity: 2, refillPerSecond: 1, maxTrackedKeys: 2, now: () => now });
  assert.equal(l.consume('a').allowed, true); assert.equal(l.consume('a').allowed, true); assert.equal(l.consume('a').allowed, false);
  l.consume('b'); l.consume('c'); assert.ok(l.size <= 2); now = 1000; assert.equal(l.consume('a').allowed, true);
});
test('guard não recomenda banimento automático', () => {
  const g = new DefensiveGuard();
  const r = g.inspect({ key: { remoteJid: '1234567890@g.us', participant: '1234567890@s.whatsapp.net' }, message: { conversation: 'oi' } });
  assert.equal(r.shouldAutoBan, false);
});
test('adaptador recebe messages.upsert e pode ser removido', async () => {
  const listeners = new Map(); const sock = { ev: { on: (n, f) => listeners.set(n, f), off: n => listeners.delete(n) } };
  let count = 0; const a = attachBaileysGuard(sock, { onResult: () => { count++; } });
  await listeners.get('messages.upsert')({ messages: [{ key: {}, message: { conversation: 'hi' } }] });
  assert.equal(count, 1); a.detach(); assert.equal(listeners.has('messages.upsert'), false);
});
test('entrada inválida não lança exceção', () => {
  assert.doesNotThrow(() => analyzeMessage(null));
});
